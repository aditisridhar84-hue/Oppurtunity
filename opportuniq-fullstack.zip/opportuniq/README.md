# OpportunIQ — Full-Stack AI Opportunity Portal

A production-ready full-stack web application that helps students find
internships, scholarships, hackathons and research programs using a
real AI matching engine.

---

## Tech Stack

| Layer      | Technology                    |
|------------|-------------------------------|
| Frontend   | HTML · CSS · Vanilla JS       |
| Backend    | Node.js · Express             |
| Database   | MongoDB · Mongoose            |
| Auth       | JWT (JSON Web Tokens)         |
| Charts     | Chart.js 4                    |
| AI Parsing | OpenAI API (optional)         |
| File Upload| Multer · pdf-parse            |

---

## Project Structure

```
opportuniq/
├── backend/
│   ├── server.js               ← Express entry point
│   ├── package.json
│   ├── .env.example            ← Copy to .env
│   ├── models/
│   │   ├── User.js             ← User schema (skills, branch, CGPA)
│   │   ├── Opportunity.js      ← Opportunity schema
│   │   └── Application.js      ← Application tracker schema
│   ├── controllers/
│   │   ├── authController.js   ← Signup, Login, JWT
│   │   ├── opportunityController.js ← CRUD + AI matching
│   │   ├── applicationController.js ← Apply, track status
│   │   ├── userController.js   ← Profile CRUD
│   │   ├── analyticsController.js   ← Real Chart.js data
│   │   └── resumeController.js ← PDF parsing + AI skill extract
│   ├── routes/
│   │   ├── auth.js
│   │   ├── opportunities.js
│   │   ├── applications.js
│   │   ├── users.js
│   │   ├── analytics.js
│   │   └── resume.js
│   ├── middleware/
│   │   └── auth.js             ← JWT protect + adminOnly
│   └── utils/
│       ├── aiMatcher.js        ← Real AI scoring engine
│       └── seed.js             ← DB seeder with real data
└── frontend/
    ├── index.html              ← Full SPA (login + app)
    └── js/
        ├── api.js              ← All API calls (fetch wrapper)
        └── app.js              ← All UI logic, auth, charts
```

---

## Setup Instructions

### Step 1 — Prerequisites

Make sure you have:
- Node.js v18 or later  →  https://nodejs.org
- MongoDB running locally  OR  a MongoDB Atlas URI

### Step 2 — Install dependencies

```bash
cd opportuniq/backend
npm install
```

### Step 3 — Configure environment

```bash
cp .env.example .env
```

Edit `.env` and set your values:

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/opportuniq
JWT_SECRET=change_this_to_a_long_random_string
JWT_EXPIRES_IN=7d
OPENAI_API_KEY=sk-...   # Optional — for AI resume parsing
FRONTEND_URL=http://localhost:5000
```

### Step 4 — Seed the database

```bash
npm run seed
```

This creates:
- 11 real verified opportunities (March 2026)
- An admin account: `admin@opportuniq.com` / `admin123456`
- A student account: `arjun@student.com` / `student123`

### Step 5 — Run the server

```bash
# Development (auto-restart)
npm run dev

# Production
npm start
```

Open your browser at:  **http://localhost:5000**

---

## API Reference

### Auth
| Method | Endpoint           | Auth     | Description        |
|--------|--------------------|----------|--------------------|
| POST   | /api/auth/signup   | Public   | Create account     |
| POST   | /api/auth/login    | Public   | Login, get JWT     |
| GET    | /api/auth/me       | JWT      | Verify token       |

### Opportunities
| Method | Endpoint                        | Auth       | Description              |
|--------|---------------------------------|------------|--------------------------|
| GET    | /api/opportunities              | Optional   | All + AI match scores    |
| GET    | /api/opportunities/recommended  | JWT        | Top matches for user     |
| GET    | /api/opportunities/urgent       | Optional   | Closing in < 7 days      |
| GET    | /api/opportunities/:id          | Optional   | Single opportunity       |
| POST   | /api/opportunities              | Admin      | Add new listing          |
| PUT    | /api/opportunities/:id          | Admin      | Update listing           |
| DELETE | /api/opportunities/:id          | Admin      | Deactivate listing       |

### Applications
| Method | Endpoint                    | Auth    | Description              |
|--------|-----------------------------|---------|--------------------------|
| POST   | /api/applications/apply     | JWT     | Apply + auto-track       |
| GET    | /api/applications           | JWT     | My applications          |
| GET    | /api/applications/all       | Admin   | All applications         |
| PUT    | /api/applications/:id/status| Admin   | Update status            |

### Users
| Method | Endpoint            | Auth    | Description         |
|--------|---------------------|---------|---------------------|
| GET    | /api/users/profile  | JWT     | Get my profile      |
| PUT    | /api/users/profile  | JWT     | Update + recalculate|

### Analytics
| Method | Endpoint            | Auth    | Description           |
|--------|---------------------|---------|-----------------------|
| GET    | /api/analytics      | Admin   | Full platform charts  |
| GET    | /api/analytics/me   | JWT     | Personal stats        |

### Resume
| Method | Endpoint               | Auth | Description              |
|--------|------------------------|------|--------------------------|
| POST   | /api/resume/upload     | JWT  | Upload PDF, extract skills|

---

## AI Matching Engine

File: `backend/utils/aiMatcher.js`

The match score (0–100%) is computed from:

| Factor           | Weight | Logic                                      |
|------------------|--------|--------------------------------------------|
| Skill overlap    | 50%    | Matched skills / total required skills     |
| Branch match     | 25%    | Exact match = full; related branch = half  |
| Year eligibility | 15%    | User year in opportunity's allowed years   |
| CGPA threshold   | 10%    | User CGPA >= minimum required CGPA         |

Skills comparison handles aliases automatically:
- "ML" matches "Machine Learning"
- "JS" matches "JavaScript"
- "py" matches "Python"

---

## Features

### Student
- JWT login / signup with skill tagging
- AI-powered opportunity recommendations (real score, not fake)
- Apply with one click — saved to MongoDB, shown in tracker
- Application tracker with status (Applied / Pending / Accepted / Rejected)
- Smart alerts for deadlines closing within 7 days
- Profile page with live sidebar sync
- Resume PDF upload — auto-extracts skills (OpenAI or keyword fallback)

### Admin
- Add / remove opportunity listings
- View all applications and update statuses
- Real-time analytics charts (Chart.js) from live DB data

### Performance
- Debounced search (400ms delay)
- Backend filtering and sorting (not frontend)
- Pagination support (page, limit params)
- Full-text MongoDB index on title, company, description
- Promise.all for parallel API calls on dashboard

---

## Using MongoDB Atlas (Cloud)

1. Go to https://cloud.mongodb.com
2. Create a free cluster
3. Click "Connect" → "Drivers" → copy the URI
4. Replace MONGO_URI in your .env:
   ```
   MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/opportuniq
   ```

---

## Adding OpenAI Resume Parsing

1. Get an API key from https://platform.openai.com
2. Add to .env:
   ```
   OPENAI_API_KEY=sk-your-key-here
   ```
3. Install the SDK:
   ```bash
   npm install openai
   ```
4. Resume uploads will now use GPT-3.5 for skill extraction.
   Falls back to keyword matching if key is missing or API fails.

---

## Production Deployment

For deployment on a VPS or cloud platform:

```bash
# Set NODE_ENV
NODE_ENV=production

# Use PM2 for process management
npm install -g pm2
pm2 start server.js --name opportuniq
pm2 save
pm2 startup
```

For Render / Railway / Fly.io:
- Set all env vars in the platform dashboard
- Build command: `npm install`
- Start command: `node server.js`
- MongoDB Atlas URI for database

---
