// controllers/opportunityController.js
const Opportunity = require('../models/Opportunity');
const { rankOpportunities, computeMatchScore, getUrgencyLabel } = require('../utils/aiMatcher');

// @desc    Get all active opportunities with AI match scores
// @route   GET /api/opportunities
// @access  Public (match scores only if authenticated)
const getOpportunities = async (req, res) => {
  try {
    const { type, search, sort, page = 1, limit = 20 } = req.query;

    // Build filter
    const filter = { isActive: true, deadline: { $gte: new Date() } };

    if (type && type !== 'all') {
      filter.type = type;
    }

    // Full-text search
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { company: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { skillsRequired: { $elemMatch: { $regex: search, $options: 'i' } } }
      ];
    }

    // Pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Opportunity.countDocuments(filter);

    let opps = await Opportunity.find(filter)
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // If user is authenticated, compute real AI match scores
    if (req.user) {
      opps = opps.map(opp => ({
        ...opp,
        matchScore: computeMatchScore(req.user, opp),
        urgency: getUrgencyLabel(opp.deadline)
      }));

      // Sort by match score if requested
      if (sort === 'match') {
        opps.sort((a, b) => b.matchScore - a.matchScore);
      } else if (sort === 'deadline') {
        opps.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
      }
    } else {
      // Guest: add urgency but no match score
      opps = opps.map(opp => ({
        ...opp,
        matchScore: null,
        urgency: getUrgencyLabel(opp.deadline)
      }));
    }

    res.json({
      success: true,
      count: opps.length,
      total,
      pages: Math.ceil(total / limit),
      data: opps
    });

  } catch (err) {
    console.error('getOpportunities error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc    Get single opportunity
// @route   GET /api/opportunities/:id
// @access  Public
const getOpportunityById = async (req, res) => {
  try {
    const opp = await Opportunity.findById(req.params.id).lean();
    if (!opp) {
      return res.status(404).json({ success: false, message: 'Opportunity not found.' });
    }

    let result = { ...opp, urgency: getUrgencyLabel(opp.deadline) };

    if (req.user) {
      result.matchScore = computeMatchScore(req.user, opp);
    }

    res.json({ success: true, data: result });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc    Get top AI-recommended opportunities for logged-in user
// @route   GET /api/opportunities/recommended
// @access  Private
const getRecommended = async (req, res) => {
  try {
    const opps = await Opportunity.find({
      isActive: true,
      deadline: { $gte: new Date() }
    }).lean();

    const ranked = rankOpportunities(req.user, opps)
      .slice(0, 6)  // Top 6 recommendations
      .map(opp => ({ ...opp, urgency: getUrgencyLabel(opp.deadline) }));

    res.json({ success: true, data: ranked });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc    Get urgent opportunities (deadline < 7 days)
// @route   GET /api/opportunities/urgent
// @access  Public
const getUrgent = async (req, res) => {
  try {
    const sevenDays = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    const opps = await Opportunity.find({
      isActive: true,
      deadline: { $gte: new Date(), $lte: sevenDays }
    }).sort({ deadline: 1 }).lean();

    const result = opps.map(opp => ({
      ...opp,
      urgency: getUrgencyLabel(opp.deadline),
      matchScore: req.user ? computeMatchScore(req.user, opp) : null
    }));

    res.json({ success: true, data: result });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc    Create new opportunity (admin only)
// @route   POST /api/opportunities
// @access  Admin
const createOpportunity = async (req, res) => {
  try {
    const opp = await Opportunity.create({
      ...req.body,
      addedBy: req.user._id
    });
    res.status(201).json({ success: true, data: opp });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

// @desc    Update opportunity (admin only)
// @route   PUT /api/opportunities/:id
// @access  Admin
const updateOpportunity = async (req, res) => {
  try {
    const opp = await Opportunity.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    if (!opp) return res.status(404).json({ success: false, message: 'Not found.' });
    res.json({ success: true, data: opp });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

// @desc    Delete (deactivate) opportunity (admin only)
// @route   DELETE /api/opportunities/:id
// @access  Admin
const deleteOpportunity = async (req, res) => {
  try {
    const opp = await Opportunity.findByIdAndUpdate(
      req.params.id,
      { isActive: false },
      { new: true }
    );
    if (!opp) return res.status(404).json({ success: false, message: 'Not found.' });
    res.json({ success: true, message: 'Opportunity removed from live listings.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = {
  getOpportunities,
  getOpportunityById,
  getRecommended,
  getUrgent,
  createOpportunity,
  updateOpportunity,
  deleteOpportunity
};
